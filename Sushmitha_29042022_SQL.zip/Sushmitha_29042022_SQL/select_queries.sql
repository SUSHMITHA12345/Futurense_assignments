
CREATE DATABASE games;
select * from games.game;
select distinct Genre from games.game;
alter table games.game rename column JP_Sales to IN_Sales;
select Name,Publisher from games.game where Year> 2000;
select * from games.game where EU_Sales>3.0 and Publisher='Nintendo';
select * from games.game where NA_Sales>3.0 and not Publisher='Nintendo';
select * from games.game order by Genre;
insert into games.game (Name,Platform,Year,Genre,Publisher,JP_Sales) values('PubG','PB5',2022,'Action','Air Entertainment',0.07);
SET SQL_SAFE_UPDATES=0;
update games.game set Genre='Racing' where Publisher='Nintendo';
delete from games.game where EU_Sales<4.00;
select * from  games.game order by NA_Sales desc limit 1;
