create table vehicle(
name varchar(30), 
model varchar(50),
regno int,
fuel varchar(50)
);
alter table games.automobile rename column `fuel-type` to fuel;
select * from games.automobile;

select automobile.fuel from games.automobile inner join games.vehicle on automobile.fuel=vehicle.fuel; 

insert into vehicle values("Audi","Car",345,"gasoline","A4"),
('Royal Enfield','Bike',123,'petrol','Meteor350'),
('Jawa','Bike',903,'petrol','jawa42'),
('BMW','Car',780,'diesel','edge9'),
('BMW','Bike',823,'petrol','nova'),
('Skoda','Car',99,'diesel','S18');
select * from games.vehicle;            
  