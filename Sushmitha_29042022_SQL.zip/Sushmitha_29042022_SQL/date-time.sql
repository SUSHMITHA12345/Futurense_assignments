insert into bday values(318,'sush','2001-02-24' ),
(118,'nand','2001-03-15' ),
(124,'divs','2001-01-28' ),
(144,'freet','2001-07-14' ),
(546,'gopp','2001-06-12' ),
(876,'thor','2000-10-28' ),
(651,'loki','2000-09-21' );
select name,extract(day from birthday) as bd from bday;
select name,extract(year from birthday) as bd from bday;
select name ,date_add(birthday,interval 10 month) as bdaymodify from bday;
select datediff('2001-03-15','2001-02-24') as datediff;
select *from bday where birthday='2001-03-15';
