import pandas as pd

df = pd.DataFrame({"Name": ["sush", "nand", "divs", "freet"], "Age": [21, 20, 22, 19],
                   ,"Stack": ["Python", "Java", "SQL", "C++"],"Salary": [80000,99000,56000,65000]})
print(df)
print(df.shape)
print(df.describe)
print(df.info)
print(df.iloc[2])
print(df.loc[df['Age'] == 1])
print(df[['Stack' , 'Salary']].iloc[1])

if len(i) > 6:
    print(i)
print(df["Name"].str.len() <4)

print(df[["Name", "Age"]].loc[df['Age'] == 22])