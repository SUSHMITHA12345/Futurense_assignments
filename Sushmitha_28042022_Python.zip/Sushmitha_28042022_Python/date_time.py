
#EXPIRY DATE OF ITEMS

from datetime import datetime

item= {"honey": datetime(2022, 4, 24).strftime("%Y-%m-%d"), "shampoo": datetime(2022, 8, 30).strftime("%Y-%m-%d"),
        "soap": datetime(2020, 12, 6).strftime("%Y-%m-%d"),"cake": datetime(2024, 7, 12).strftime("%Y-%m-%d")}
print(item)


def disc(item):
    for i in item.values():
        l1 = []
        if i - datetime.timedelta(months=1) > 10:
            l1.append(i)
        print(l1)

