#LIST COMPREHENSIONS
nmbr=[15,24,3,2,36,9]
n1=[x**3 for i in L]
n2=[x**4 for i in nmbr if i/2!=0]
print(n1)
print(n2)

#DICTIONARY COMPREHENSION

price = {'toys': 250, 'pen': 15, 'lotion': 399, 'shirt': 2549}
gst = 15
bill = {item: value*gst for (item, value) in price.items()}
print(bill)
