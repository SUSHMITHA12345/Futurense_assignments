RESTAURANT MENU:

l = ['fruits', 'biryanis', 'rotis', 'dessert']
l.append('noodles')
l.extend('drinks')
a = ['apple', 'orange', 'banana', 'mango', 'kiwi']
b = ['chicken biryani', 'mutton biryani', 'prawn biryani', 'fish biryani']
c = ['naan', 'pulka', 'chapati', 'butter naan']
d = ['pastry', 'ice-cream', 'cake', 'sweet']
e = ['schezwan', 'manchurian', 'veg', 'non-veg']
f = ['tea', 'coffee', 'cold drinks', 'shakes']
l1 = []
item = 'fruits'
prod = 'mango'
for i in l:
    if i == item:
        l1 = a
    elif i == item:
        l1 = b
    elif i == item:
        l1 = c
    elif i == item:
        l1 = d
    elif i == item:
        l1 = e
    elif i == item:
        l1 = f

print(l1)
print(l1[1:6:2])
print(l1.reverse())
print(len(l1))
print(l+l1)

