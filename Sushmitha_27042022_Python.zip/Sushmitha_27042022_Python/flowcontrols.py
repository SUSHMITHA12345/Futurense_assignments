"""flow controls"""
"""for, while, do-while
if, elif, else"""

WALLPAPER:

color=["blue","black","white","grey","purple"]
theme=["floral","dark","wild","anime","beach"]
a="purple"
b="anime"
for i in range(len(color)):
    for j in range(len(theme)):
        if (b==theme[j]):
            if (a==color[i]):
               color[i]=a
            else:
                theme[j]=b

print(color[i])
print(theme[j])



