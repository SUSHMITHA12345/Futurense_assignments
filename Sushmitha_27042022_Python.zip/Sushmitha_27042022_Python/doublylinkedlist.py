class Node:
    def __init__(self, data, next=None, prev=None):
        self.data = data
        self.next = next
        self.prev = prev


class DoublyLinkedList:
    def__init__(self):
    self.head = None
    self.tail = None


def push_front(self, new_data):
    new_node = Node(new_data)
    new_node.next = self.head
    if self.head != None:
        self.head.prev = new_node
        self.head = new_node
        new_node.prev = None

    else:
        self.head = new_node
        self.tail = new_node
        new_node.prev = None


def push_back(self, new_data):
    new_node = Node(new_data)
    new_node.prev = self.tail
    if self.tail != None:
        self.tail.next = new_node
        self.tail = new_node
        new_node.next = None

    else:
        self.tail = new_node
        self.head = new_node
        new_node.next = None


def peek_front(self):
    if self.head != None:
        return self.head.data
    else:
        print('empty list')


def peek_back(self):
    if self.tail != None:
        return self.tail.data
    else:
        print('empty list')


def pop_front(self):
    if self.head != None:
        temp = self.head
        temp.prev = None
        self.head = temp.next
        temp.next = None
        return temp.data
    else:
        print('empty list')


def pop_back(self):
    if self.tail != None:
        temp = self.tail
        temp.next = None
        self.tail = temp.prev
        temp.prev = None
        return temp.data
    else:
        print('empty list')


def insert_after(self, temp_node, new_data):
    if temp_node != None:
        new_node = Node(new_data)
        new_node.next = temp_node.next
        temp_node.next = new_node
        new_node.prev = temp_node

        if new_node.next != None:
            new_node.next = new_node

        if temp_node == self.tail:
            self.tail = new_node

    else:
        print('empty node')


def insert_before(self, temp_node, new_data):
    if temp_node != None:
        new_node = Node(new_data)
        new_node.prev = temp_node.prev
        temp_node.prev = new_node
        new_node.next = temp_node

        if new_node.prev != None:
            new_node.prev = new_node

        if temp_node == self.head:
            self.head = new_node

    else:
        print('empty node')









