"""arithematic: +,-,*,/,//,**,%
logical:and , or ,not
assignment:=,+=,-+,*=,/=,*=,//=,**=
identity:is, is not
membership:in , not in
bitwise:&,!,^,~,<<,>>
comparison:==,!=,>,<,>=,<="""

SHOPPING CART BILLING:

cart=['watch','jean','phone','ring']
prod='watch'
price=2000
n=12000
bill=0
gst=6
total=0

if prod in cart:
    if (n==10000 or n> 10000):
        bill+= n- (75/100)*n
    elif (n > 5000) or (n < 10000):
        bill+= n - (50/100)*n
    elif (n > 4000) and (n < 5000):
        bill+= n - (30/100)*n
    elif (n >3000) and (n < 2000):
        bill+= n - (25/100)*n
    else:
        bill+=n
    total+=bill+(gst/100)*bill
else:
   cart.append(prod)
   n+=price
   if (n == 10000 or n > 10000):
       bill += n - (75 / 100) * n
   elif (n > 5000) or (n < 10000):
       bill += n - (50 / 100) * n
   elif (n > 4000) and (n < 5000):
       bill += n - (30 / 100) * n
   elif (n > 3000) and (n < 2000):
       bill += n - (25 / 100) * n
   else:
       bill += n
   total += bill + (gst / 100) * bill

print(total)





