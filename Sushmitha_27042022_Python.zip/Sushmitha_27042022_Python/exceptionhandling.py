CHARGING TIME FOR MOBILE:

def calc(mah,v,w):
    try:
        charge= (mah*v)
        t=(charge/w)
        print(t)
    except ZeroDivisionError:
        print("error")
    finally:
        print("Charging")
calc(5000,5,10)
calc(5000,5,0)


#WITHOUT EXCEPT
def calc(mah,v,w):
    try:
        charge= (mah*v)
        t=(charge/w)
        print(t)

    finally:
        print("Charging")
calc(5000,5,10)
calc(5000,5,0)
